<html><link type="text/css" rel="stylesheet" href="http://dictybase.org/assets/stylesheets/blast.css"><body>
<div id='blast-graph' class='block-container'><img style="overflow:hidden;top:0px" src="../tmp/b740e6c88caf4366b64b74daa1526b6a.output.graph.png"  usemap="#bgmap00001" border=1/><map name="bgmap00001" id="bgmap00001">
<area shape="rect" coords="10,0,117,52" href="#POPTR_0002s19720.1"  />
<area shape="rect" coords="10,58,123,97" href="#POPTR_0002s19720.1"  />
<area shape="rect" coords="27,100,206,139" href="#POPTR_0014s11590.1"  />
<area shape="rect" coords="34,142,207,181" href="#POPTR_0005s25290.1"  />
<area shape="rect" coords="10,187,117,239" href="#POPTR_0006s11770.1"  />
<area shape="rect" coords="10,245,123,284" href="#POPTR_0006s11770.2"  />
<area shape="rect" coords="10,287,123,326" href="#POPTR_0006s11770.1"  />
<area shape="rect" coords="20,329,133,368" href="#POPTR_0006s11770.2"  />
<area shape="rect" coords="20,371,133,410" href="#POPTR_0006s11770.1"  />
<area shape="rect" coords="32,413,205,452" href="#POPTR_0004s20020.2"  />
<area shape="rect" coords="32,455,205,494" href="#POPTR_0004s20020.1"  />
<area shape="rect" coords="32,497,205,536" href="#POPTR_0004s20020.2"  />
<area shape="rect" coords="32,539,205,578" href="#POPTR_0004s20020.1"  />
<area shape="rect" coords="20,581,193,620" href="#POPTR_0009s15160.1"  />
<area shape="rect" coords="10,626,117,678" href="#POPTR_0011s10540.1"  />
<area shape="rect" coords="13,684,126,723" href="#POPTR_0011s10540.1"  />
<area shape="rect" coords="34,768,147,807" href="#POPTR_0017s08320.1"  />
<area shape="rect" coords="27,726,140,765" href="#POPTR_0001s32300.1"  />
<area shape="rect" coords="10,813,117,865" href="#POPTR_0007s07730.1"  />
<area shape="rect" coords="10,871,123,910" href="#POPTR_0007s07730.1"  />
<area shape="rect" coords="10,913,123,952" href="#POPTR_0005s09520.1"  />
<area shape="rect" coords="14,955,193,994" href="#POPTR_0007s07730.1"  />
<area shape="rect" coords="14,997,193,1036" href="#POPTR_0005s09520.1"  />
<area shape="rect" coords="14,1039,193,1078" href="#POPTR_0175s00210.1"  />
<area shape="rect" coords="14,1081,187,1120" href="#POPTR_0010s25800.1"  />
<area shape="rect" coords="14,1123,187,1162" href="#POPTR_0008s00790.1"  />
<area shape="rect" coords="10,1168,117,1220" href="#POPTR_0006s13370.1"  />
<area shape="rect" coords="10,1226,123,1265" href="#POPTR_0006s13370.1"  />
<area shape="rect" coords="15,1268,128,1307" href="#POPTR_0016s08710.1"  />
<area shape="rect" coords="17,1310,196,1349" href="#POPTR_0010s22410.1"  />
<area shape="rect" coords="17,1352,196,1391" href="#POPTR_0008s04400.1"  />
<area shape="rect" coords="10,1397,810,1449" href="#POPTR_0002s11160.1"  />
<area shape="rect" coords="10,1455,810,1494" href="#POPTR_0002s11160.1"  />
<area shape="rect" coords="10,1497,810,1536" href="#POPTR_0002s11160.2"  />
<area shape="rect" coords="507,1539,680,1578" href="#POPTR_0005s19610.1"  />
<area shape="rect" coords="614,1581,787,1620" href="#POPTR_0005s19600.1"  />
<area shape="rect" coords="10,1626,121,1678" href="#POPTR_0002s02390.1"  />
<area shape="rect" coords="10,1684,123,1723" href="#POPTR_0002s02390.1"  />
<area shape="rect" coords="34,1726,147,1765" href="#POPTR_0005s26050.1"  />
<area shape="rect" coords="45,1768,218,1807" href="#POPTR_0009s13150.1"  />
<area shape="rect" coords="45,1810,218,1849" href="#POPTR_0004s17470.1"  />
<area shape="rect" coords="10,1855,117,1907" href="#POPTR_0010s18590.1"  />
<area shape="rect" coords="10,1913,123,1952" href="#POPTR_0010s18590.1"  />
<area shape="rect" coords="21,1955,194,1994" href="#POPTR_0008s07780.1"  />
<area shape="rect" coords="10,2000,117,2052" href="#POPTR_0001s28670.1"  />
<area shape="rect" coords="10,2058,123,2097" href="#POPTR_0001s28670.1"  />
<area shape="rect" coords="10,2103,136,2155" href="#POPTR_0001s28570.1"  />
<area shape="rect" coords="10,2161,136,2200" href="#POPTR_0001s28570.1"  />
<area shape="rect" coords="10,2203,136,2242" href="#POPTR_0001s28570.3"  />
<area shape="rect" coords="10,2245,136,2284" href="#POPTR_0001s28570.2"  />
<area shape="rect" coords="17,2329,130,2368" href="#POPTR_0001s28570.3"  />
<area shape="rect" coords="17,2371,130,2410" href="#POPTR_0001s28570.2"  />
<area shape="rect" coords="14,2287,135,2326" href="#POPTR_0009s07770.1"  />
<area shape="rect" coords="10,2416,117,2468" href="#POPTR_0004s17470.1"  />
<area shape="rect" coords="10,2474,123,2513" href="#POPTR_0004s17470.1"  />
<area shape="rect" coords="15,2516,128,2555" href="#POPTR_0009s13150.1"  />
<area shape="rect" coords="29,2558,202,2597" href="#POPTR_0002s02390.1"  />
<area shape="rect" coords="29,2600,202,2639" href="#POPTR_0005s26050.1"  />
<area shape="rect" coords="10,2645,173,2697" href="#POPTR_0001s28760.1"  />
<area shape="rect" coords="10,2703,173,2742" href="#POPTR_0001s28760.1"  />
<area shape="rect" coords="10,2745,172,2784" href="#POPTR_0009s07970.1"  />
</map>
</div>
</body>
</html>
